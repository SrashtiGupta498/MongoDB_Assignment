const mongoose = require('mongoose');

// Use encodeURIComponent to encode special characters in username and password
const username = encodeURIComponent('Clavax');
const password = encodeURIComponent('Tech@123');

// MongoDB URI with SSL/TLS
const uri = `mongodb://${username}:${password}@127.0.0.1:27017/exampleDB?tls=true&tlsCAFile=C:\\mycerts\\mongodb-test-ca.crt&tlsCertificateKeyFile=C:\\mycerts\\server.pem`;

// Connect to MongoDB
mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(async () => {
        console.log('Connected to MongoDB with TLS');

        // Create a user
        const db = mongoose.connection.db;
        await db.command({
            createUser: "Clavax",
            pwd: "Tech@123",
            roles: [{ role: "readWrite", db: "exampleDB" }]
        });

        // Create a collection and insert a geospatial document
        await db.createCollection("locations");
        await db.collection("locations").insertOne({
            name: "Sample Location",
            coordinates: { type: "Point", coordinates: [-73.856077, 40.848447] }
        });

        // Create a 2dsphere index
        await db.collection("locations").createIndex({ coordinates: "2dsphere" });

        // Enable slow query logging
        await db.command({ profile: 1, slowms: 100 });

        // Retrieve slow queries (only run this once to see results)
        const slowQueries = await db.collection("system.profile").find().sort({ ts: -1 }).limit(5).toArray();
        console.log('Recent slow queries:', slowQueries);
        
        // Close the connection after operations
        mongoose.connection.close();
    })
    .catch(err => {
        console.error('Error connecting to MongoDB', err);
    });
