#!/bin/bash

TIMESTAMP=$(date +"%F")
BACKUP_DIR="/path/to/backup/directory/$TIMESTAMP"  # Specify your backup directory
mkdir -p "$BACKUP_DIR"
mongodump --ssl --sslCAFile "C:\mycerts\mongodb-test-ca.crt" -u Clavax -p Tech@123 --authenticationDatabase exampleDB --out "$BACKUP_DIR"
